# Mini Netlix
 Mini Netflix bases on PostgreSQL and NodeJS
